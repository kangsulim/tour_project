package com.example.tour_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
